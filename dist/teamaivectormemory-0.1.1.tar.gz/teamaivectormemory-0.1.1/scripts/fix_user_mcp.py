"""清理用户级 MCP 配置中的重复 teamaivectormemory 条目"""
import json
from pathlib import Path

filepath = Path.home() / ".kiro/settings/mcp.json"
config = json.loads(filepath.read_text("utf-8"))

if "teamaivectormemory" in config.get("mcpServers", {}):
    del config["mcpServers"]["teamaivectormemory"]
    filepath.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"✓ 已删除用户级 teamaivectormemory 条目: {filepath}")
    print(f"  剩余 servers: {list(config['mcpServers'].keys())}")
else:
    print("- 用户级配置中没有 teamaivectormemory，无需修改")
