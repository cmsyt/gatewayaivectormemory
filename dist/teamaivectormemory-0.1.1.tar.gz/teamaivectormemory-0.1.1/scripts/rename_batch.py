"""Batch replace aivectormemory -> teamaivectormemory in source files"""
import re
from pathlib import Path

ROOT = Path(__file__).parent.parent

# Files to process (source code only, not docs/README yet)
source_files = list(ROOT.glob("teamaivectormemory/**/*.py"))

count = 0
for f in source_files:
    if "__pycache__" in str(f):
        continue
    text = f.read_text("utf-8")
    # Replace import paths and string references
    new_text = text.replace("from aivectormemory.", "from teamaivectormemory.")
    new_text = new_text.replace("import aivectormemory", "import teamaivectormemory")
    new_text = new_text.replace('"aivectormemory"', '"teamaivectormemory"')
    new_text = new_text.replace("[aivectormemory]", "[teamaivectormemory]")
    new_text = new_text.replace("aivectormemory install", "teamaivectormemory install")
    new_text = new_text.replace('"-m", "aivectormemory"', '"-m", "teamaivectormemory"')
    new_text = new_text.replace('"aivectormemory@latest"', '"teamaivectormemory@latest"')
    new_text = new_text.replace(".aivectormemory", ".teamaivectormemory")
    new_text = new_text.replace("aivectormemory-pre-tool-check", "teamaivectormemory-pre-tool-check")
    new_text = new_text.replace("aivectormemory-steering", "teamaivectormemory-steering")
    new_text = new_text.replace("/aivectormemory.md", "/teamaivectormemory.md")
    new_text = new_text.replace("pip install aivectormemory", "pip install teamaivectormemory")
    new_text = new_text.replace('"""aivectormemory', '"""teamaivectormemory')
    if new_text != text:
        f.write_text(new_text, "utf-8")
        count += 1
        print(f"  ✓ {f.relative_to(ROOT)}")

print(f"\nUpdated {count} source files")
