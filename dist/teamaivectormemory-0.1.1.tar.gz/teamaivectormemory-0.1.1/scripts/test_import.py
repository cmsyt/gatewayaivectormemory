"""验证 teamaivectormemory 模块能正常导入"""
import sys
sys.path.insert(0, ".")

try:
    import teamaivectormemory
    print(f"✓ import teamaivectormemory OK, version={teamaivectormemory.__version__}")
except Exception as e:
    print(f"✗ import teamaivectormemory FAILED: {e}")
    sys.exit(1)

try:
    from teamaivectormemory.server import MCPServer
    print("✓ from teamaivectormemory.server import MCPServer OK")
except Exception as e:
    print(f"✗ server import FAILED: {e}")
    sys.exit(1)

try:
    from teamaivectormemory.install import RUNNERS, IDES
    print(f"✓ install.py OK, {len(RUNNERS)} runners, {len(IDES)} IDEs")
except Exception as e:
    print(f"✗ install import FAILED: {e}")
    sys.exit(1)

try:
    from teamaivectormemory.web.app import run_web
    print("✓ web.app import OK")
except Exception as e:
    print(f"✗ web.app import FAILED: {e}")
    sys.exit(1)

print("\n全部导入测试通过")
