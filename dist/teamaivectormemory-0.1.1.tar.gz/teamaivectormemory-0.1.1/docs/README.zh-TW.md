🌐 [简体中文](../README.md) | 繁體中文 | [English](README.en.md) | [Español](README.es.md) | [Deutsch](README.de.md) | [Français](README.fr.md) | [日本語](README.ja.md)

<p align="center">
  <h1 align="center">🧠 TeamAIVectorMemory</h1>
  <p align="center">
    <strong>為 AI 程式助手裝上團隊記憶 — 多人協作 · 知識共享 · 跨會話持久化 MCP Server</strong>
  </p>
  <p align="center">
    <a href="https://pypi.org/project/teamaivectormemory/"><img src="https://img.shields.io/pypi/v/teamaivectormemory?color=blue&label=PyPI" alt="PyPI"></a>
    <a href="https://pypi.org/project/teamaivectormemory/"><img src="https://img.shields.io/pypi/pyversions/teamaivectormemory" alt="Python"></a>
    <a href="https://github.com/cmsyt/teamaivectormemory/blob/main/LICENSE"><img src="https://img.shields.io/badge/license-Apache_2.0-green" alt="License"></a>
    <a href="https://modelcontextprotocol.io"><img src="https://img.shields.io/badge/MCP-compatible-purple" alt="MCP"></a>
  </p>
</p>

---

> **你是否也有這樣的困擾？** 每開一個新會話，AI 就像換了個人 — 昨天剛教會它的專案規範今天又忘了，踩過的坑還會再踩一遍，開發到一半的進度全部歸零。團隊裡每個人都在重複踩同樣的坑，知識無法沉澱，經驗無法傳承。
>
> **TeamAIVectorMemory 是為團隊打造的 AI 記憶中樞。** 不只是個人記憶 — 團隊踩坑經驗自動共享，架構知識一人沉澱全員受益，多用戶資料嚴格隔離互不干擾。支援多 worker 共享 Embedding 模型，N 個進程只需 1 份記憶體。新會話自動恢復上下文，語義搜尋精準召回，Token 消耗直降 50%+。

## ✨ 核心特性

| 特性 | 說明 |
|------|------|
| 👥 **團隊知識共享** | 一人踩坑全員受益 — 團隊記憶自動共享，架構知識、踩坑經驗沉澱為團隊資產，新人即刻獲得老手的全部經驗 |
| 🔐 **多用戶資料隔離** | 同一台伺服器多人協作，個人記憶嚴格隔離互不可見，團隊記憶按專案共享，隱私與協作兼得 |
| ⚡ **Embedding 共享服務** | N 個 MCP worker 共享一個 Embedding 模型，200MB × N → 200MB × 1，伺服器部署記憶體直降 90% |
| 🧠 **跨會話記憶** | AI 終於能記住你的專案了 — 踩過的坑、做過的決策、定下的規範，換個會話照樣記得 |
| 🔍 **語義搜尋** | 不用記原文怎麼寫的，搜「資料庫逾時」就能找到「MySQL 連線池踩坑」 |
| 💰 **省 50%+ Token** | 不再每次對話都複製貼上專案背景，語義檢索按需召回，告別全量上下文注入 |
| 🔗 **任務驅動開發** | 問題追蹤 → 任務拆分 → 狀態同步 → 聯動歸檔，AI 自動管理完整開發流程 |
| 📊 **Web 看板** | 視覺化管理所有記憶和任務，3D 向量網路一眼看清知識關聯 |
| 🏠 **完全本地** | 零依賴雲端服務，ONNX 本地推理，無需 API Key，資料不出你的電腦 |
| 🔌 **全 IDE 通吃** | Cursor / Kiro / Claude Code / Windsurf / VSCode / OpenCode / Trae — 一鍵安裝，開箱即用 |
| 📁 **多專案隔離** | 一個 DB 管所有專案，自動隔離互不干擾，切換專案無感知 |
| 🔄 **智慧去重** | 相似度 > 0.95 自動合併更新，記憶庫永遠乾淨，不會越用越亂 |

## 🏗️ 架構

```
┌─────────────────────────────────────────────────┐
│                   AI IDE                         │
│  OpenCode / Claude Code / Cursor / Kiro / ...   │
└──────────────────────┬──────────────────────────┘
                       │ MCP Protocol (stdio)
┌──────────────────────▼──────────────────────────┐
│              TeamAIVectorMemory Server               │
│                                                  │
│  ┌──────────┐ ┌──────────┐ ┌──────────────────┐ │
│  │ remember │ │  recall   │ │   auto_save      │ │
│  │ forget   │ │  task     │ │   status/track   │ │
│  └────┬─────┘ └────┬─────┘ └───────┬──────────┘ │
│       │            │               │             │
│  ┌────▼────────────▼───────────────▼──────────┐  │
│  │         Embedding Engine (ONNX)            │  │
│  │      intfloat/multilingual-e5-small        │  │
│  └────────────────────┬───────────────────────┘  │
│                       │                          │
│  ┌────────────────────▼───────────────────────┐  │
│  │     SQLite + sqlite-vec（向量索引）         │  │
│  │     ~/.teamaivectormemory/memory.db            │  │
│  └────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────┘
```

## 🚀 快速開始

### 方式一：pip 安裝（推薦）

```bash
# 安裝
pip install teamaivectormemory

# 升級到最新版
pip install --upgrade teamaivectormemory

# 進入你的專案目錄，一鍵配置 IDE
cd /path/to/your/project
team-run install
```

`team-run install` 會互動式引導你選擇 IDE，自動生成 MCP 配置、Steering 規則和 Hooks，無需手動編寫。

> **macOS 使用者注意**：
> - 遇到 `externally-managed-environment` 錯誤，加 `--break-system-packages`
> - 遇到 `enable_load_extension` 錯誤，說明當前 Python 不支援 SQLite 擴展載入（macOS 自帶 Python 和 python.org 官方安裝包均不支援），請改用 Homebrew Python：
>   ```bash
>   brew install python
>   /opt/homebrew/bin/python3 -m pip install teamaivectormemory
>   ```

### 方式二：uvx 執行（零安裝）

無需 `pip install`，直接執行：

```bash
cd /path/to/your/project
uvx teamaivectormemory install
```

> 需要先安裝 [uv](https://docs.astral.sh/uv/getting-started/installation/)，`uvx` 會自動下載並執行，無需手動安裝套件。

### 方式三：手動配置

```json
{
  "mcpServers": {
    "teamaivectormemory": {
      "command": "team-run",
      "args": ["--project-dir", "/path/to/your/project"]
    }
  }
}
```

<details>
<summary>📍 各 IDE 設定檔位置</summary>

| IDE | 設定檔路徑 |
|-----|------------|
| Kiro | `.kiro/settings/mcp.json` |
| Cursor | `.cursor/mcp.json` |
| Claude Code | `.mcp.json` |
| Windsurf | `.windsurf/mcp.json` |
| VSCode | `.vscode/mcp.json` |
| Trae | `.trae/mcp.json` |
| OpenCode | `opencode.json` |
| Claude Desktop | `~/Library/Application Support/Claude/claude_desktop_config.json` |

</details>

## 🛠️ 8 個 MCP 工具

### `remember` — 存入記憶

```
content (string, 必填)   記憶內容，Markdown 格式
tags    (string[], 必填)  標籤，如 ["踩坑", "python"]
scope   (string)          "project"（預設）/ "user"（跨專案）
```

相似度 > 0.95 自動更新已有記憶，不重複儲存。

### `recall` — 語義搜尋

```
query   (string)     語義搜尋關鍵詞
tags    (string[])   標籤精確過濾
scope   (string)     "project" / "user" / "all"
top_k   (integer)    回傳數量，預設 5
```

向量相似度匹配，用詞不同也能找到相關記憶。

### `forget` — 刪除記憶

```
memory_id  (string)     單個 ID
memory_ids (string[])   批次 ID
```

### `status` — 會話狀態

```
state (object, 可選)   不傳=讀取，傳=更新
  is_blocked, block_reason, current_task,
  next_step, progress[], recent_changes[], pending[]
```

跨會話保持工作進度，新會話自動恢復上下文。

### `track` — 問題追蹤

```
action   (string)   "create" / "update" / "archive" / "list"
title    (string)   問題標題
issue_id (integer)  問題 ID
status   (string)   "pending" / "in_progress" / "completed"
content  (string)   排查內容
```

### `task` — 任務管理

```
action     (string, 必填)  "batch_create" / "update" / "list" / "delete" / "archive"
feature_id (string)        關聯功能標識（list 時必填）
tasks      (array)         任務列表（batch_create，支援子任務）
task_id    (integer)       任務 ID（update）
status     (string)        "pending" / "in_progress" / "completed" / "skipped"
```

透過 feature_id 關聯 spec 文件，update 自動同步 tasks.md checkbox 並聯動問題狀態。

### `readme` — README 生成

```
action   (string)    "generate"（預設）/ "diff"（差異對比）
lang     (string)    語言：en / zh-TW / ja / de / fr / es
sections (string[])  指定章節：header / tools / deps
```

從 TOOL_DEFINITIONS / pyproject.toml 自動生成 README 內容，支援多語言。

### `auto_save` — 自動儲存偏好

```
preferences  (string[])  使用者表達的技術偏好（固定 scope=user，跨專案通用）
extra_tags   (string[])  額外標籤
```

每次對話結束自動提取並儲存使用者偏好，智慧去重。

## 📊 Web 看板

```bash
team-run web --port 9080
team-run web --port 9080 --quiet          # 屏蔽請求日誌
team-run web --port 9080 --quiet --daemon  # 背景執行（macOS/Linux）
```

瀏覽器存取 `http://localhost:9080`

- 多專案切換，記憶瀏覽/搜尋/編輯/刪除/匯出/匯入
- 語義搜尋（向量相似度匹配）
- 專案資料一鍵刪除
- 會話狀態、問題追蹤
- 標籤管理（重新命名、合併、批次刪除）
- Token 認證保護
- 3D 向量記憶網路視覺化
- 🌐 多語言支援（简体中文 / 繁體中文 / English / Español / Deutsch / Français / 日本語）

<p align="center">
  <img src="dashboard-projects.png" alt="專案選擇" width="100%">
  <br>
  <em>專案選擇</em>
</p>

<p align="center">
  <img src="dashboard-overview.png" alt="統計概覽 & 向量網路視覺化" width="100%">
  <br>
  <em>統計概覽 & 向量網路視覺化</em>
</p>

## ⚡ Embedding 共享服務

多個 MCP worker 共享一個 Embedding 模型，避免每個進程各載入一份（200MB × N → 200MB × 1）。

```bash
# 啟動 Embedding 共享服務（預設端口 8900）
team-run embed-server
team-run embed-server --port 8900              # 指定端口
team-run embed-server --port 8900 --daemon     # 背景執行（macOS/Linux）
team-run embed-server --bind 0.0.0.0           # 允許遠端存取
```

MCP worker 透過環境變數連接共享服務：

```json
{
  "mcpServers": {
    "teamaivectormemory": {
      "command": "team-run",
      "args": ["--project-dir", "/path/to/your/project"],
      "env": { "EMBEDDING_SERVER_URL": "http://127.0.0.1:8900" }
    }
  }
}
```

- 設定 `EMBEDDING_SERVER_URL` 後，EmbeddingEngine 自動切換為遠端模式，透過 HTTP 呼叫共享服務
- 共享服務不可用時自動回退到本地模式，不影響正常使用
- HTTP 介面：`GET /health`（健康檢查）、`POST /encode`（單文本編碼）、`POST /encode_batch`（批次編碼）

## ⚡ 搭配 Steering 規則

TeamAIVectorMemory 是儲存層，透過 Steering 規則告訴 AI **何時、如何**呼叫這些工具。

執行 `team-run install` 會自動產生 Steering 規則和 Hooks 設定，無需手動編寫。

| IDE | Steering 位置 | Hooks |
|-----|--------------|-------|
| Kiro | `.kiro/steering/teamaivectormemory.md` | `.kiro/hooks/*.hook` |
| Cursor | `.cursor/rules/teamaivectormemory.md` | `.cursor/hooks.json` |
| Claude Code | `CLAUDE.md`（追加） | `.claude/settings.json` |
| Windsurf | `.windsurf/rules/teamaivectormemory.md` | `.windsurf/hooks.json` |
| VSCode | `.github/copilot-instructions.md`（追加） | — |
| Trae | `.trae/rules/teamaivectormemory.md` | — |
| OpenCode | `AGENTS.md`（追加） | `.opencode/plugins/*.js` |

<details>
<summary>📋 Steering 規則範例（自動產生）</summary>

```markdown
# TeamAIVectorMemory - 工作規則

## 1. 新會話啟動（必須按順序執行）

1. `recall`（tags: ["項目知識"], scope: "project", top_k: 100）載入項目知識
2. `recall`（tags: ["preference"], scope: "user", top_k: 20）載入使用者偏好
3. `status`（不傳 state）讀取會話狀態
4. 有阻塞 → 匯報並等待；無阻塞 → 進入處理流程

## 2. 收到訊息後的處理流程

- 步驟 A：`status` 讀取狀態，有阻塞則等待
- 步驟 B：判斷訊息類型（閒聊/糾正/偏好/程式碼問題）
- 步驟 C：`track create` 記錄問題
- 步驟 D：排查（`recall` 查踩坑 + 查看程式碼 + 找根因）
- 步驟 E：向使用者說明方案，設阻塞等確認
- 步驟 F：修改程式碼（修改前 `recall` 查踩坑）
- 步驟 G：執行測試驗證
- 步驟 H：設阻塞等待使用者驗證
- 步驟 I：使用者確認 → `track archive` + 清阻塞

## 3. 阻塞規則

提方案等確認、修復完等驗證時必須 `status({ is_blocked: true })`。
使用者明確確認後才能清除阻塞，禁止自行清除。

## 4-9. 問題追蹤 / 程式碼檢查 / Spec 任務管理 / 記憶品質 / 工具速查 / 開發規範

（完整規則由 `team-run install` 自動產生）
```

</details>

<details>
<summary>🔗 Hooks 設定範例（Kiro 專屬，自動產生）</summary>

會話結束自動儲存已移除，開發流程檢查（`.kiro/hooks/dev-workflow-check.kiro.hook`）：

```json
{
  "enabled": true,
  "name": "開發流程檢查",
  "version": "1",
  "when": { "type": "promptSubmit" },
  "then": {
    "type": "askAgent",
    "prompt": "核心原則：操作前驗證、禁止盲目測試、自測通過才能說完成"
  }
}
```

</details>

## 🇨🇳 中國大陸使用者

首次執行自動下載 Embedding 模型（~200MB），如果慢：

```bash
export HF_ENDPOINT=https://hf-mirror.com
```

或在 MCP 設定中加 env：

```json
{
  "env": { "HF_ENDPOINT": "https://hf-mirror.com" }
}
```

## 📦 技術棧

| 元件 | 技術 |
|------|------|
| 執行環境 | Python >= 3.10 |
| 向量資料庫 | SQLite + sqlite-vec |
| Embedding | ONNX Runtime + intfloat/multilingual-e5-small |
| 分詞器 | HuggingFace Tokenizers |
| 協議 | Model Context Protocol (MCP) |
| Web | 原生 HTTPServer + Vanilla JS |

## 📋 更新日誌

### v0.1.1

**Embedding 共享服務**
- ⚡ 新增 `team-run embed-server` 子命令，啟動獨立的 Embedding HTTP 服務（支援 `--port`/`--bind`/`--daemon` 參數）
- ⚡ HTTP 介面：`GET /health`（健康檢查）、`POST /encode`（單文本編碼）、`POST /encode_batch`（批次編碼）
- ⚡ EmbeddingEngine 支援遠端/本地雙模式：設定 `EMBEDDING_SERVER_URL` 環境變數自動切換遠端模式
- ⚡ 遠端服務不可用時自動回退到本地 ONNX 推理，零感知降級
- ⚡ N 個 MCP worker 共享一個 Embedding 模型，200MB × N → 200MB × 1，記憶體直降 90%

## License

Apache-2.0
