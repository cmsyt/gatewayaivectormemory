🌐 [简体中文](../README.md) | [繁體中文](README.zh-TW.md) | [English](README.en.md) | [Español](README.es.md) | Deutsch | [Français](README.fr.md) | [日本語](README.ja.md)

<p align="center">
  <h1 align="center">🧠 TeamAIVectorMemory</h1>
  <p align="center">
    <strong>Gib deinem KI-Programmierassistenten ein Team-Gedächtnis — Multi-User-Zusammenarbeit · Wissensaustausch · Sitzungsübergreifender persistenter Speicher MCP Server</strong>
  </p>
  <p align="center">
    <a href="https://pypi.org/project/teamaivectormemory/"><img src="https://img.shields.io/pypi/v/teamaivectormemory?color=blue&label=PyPI" alt="PyPI"></a>
    <a href="https://pypi.org/project/teamaivectormemory/"><img src="https://img.shields.io/pypi/pyversions/teamaivectormemory" alt="Python"></a>
    <a href="https://github.com/cmsyt/teamaivectormemory/blob/main/LICENSE"><img src="https://img.shields.io/badge/license-Apache_2.0-green" alt="License"></a>
    <a href="https://modelcontextprotocol.io"><img src="https://img.shields.io/badge/MCP-compatible-purple" alt="MCP"></a>
  </p>
</p>

---

> **Kommt dir das bekannt vor?** Jede neue Sitzung startet deine KI von Null — Projektkonventionen, die du ihr gestern beigebracht hast? Vergessen. Fehler, die sie schon gemacht hat? Macht sie wieder. Halbfertige Arbeit? Weg. Schlimmer noch: Jedes Teammitglied tritt unabhängig in dieselben Fallen, Wissen sammelt sich nie an, Erfahrung wird nie weitergegeben.
>
> **TeamAIVectorMemory ist der KI-Gedächtnis-Hub für Teams.** Nicht nur persönliches Gedächtnis — Team-Fehlererfahrungen werden automatisch geteilt, Architekturwissen von einem hinterlegt profitiert alle. Multi-User-Daten sind strikt isoliert ohne Kreuzkontamination. Unterstützt gemeinsame Nutzung des Embedding-Modells durch mehrere Worker: N Prozesse, 1 Kopie im Speicher. Neue Sitzungen stellen den Kontext automatisch wieder her, semantische Suche ruft genau das Richtige ab, und der Token-Verbrauch sinkt um 50%+.

## ✨ Kernfunktionen

| Funktion | Beschreibung |
|----------|-------------|
| 👥 **Team-Wissensaustausch** | Ein Fehler einer Person wird zur Lektion für alle — Team-Erinnerungen werden automatisch geteilt, Architekturwissen und Fehlererfahrungen werden zu Team-Assets, neue Mitglieder erben sofort die gesamte Erfahrung der Veteranen |
| 🔐 **Multi-User-Datenisolation** | Mehrere Benutzer auf einem Server, persönliche Erinnerungen strikt isoliert und unsichtbar für andere, Team-Erinnerungen projektweise geteilt — Privatsphäre und Zusammenarbeit vereint |
| ⚡ **Gemeinsamer Embedding-Service** | N MCP-Worker teilen sich ein Embedding-Modell, 200MB × N → 200MB × 1, Server-Speicherverbrauch sinkt um 90% |
| 🧠 **Sitzungsübergreifendes Gedächtnis** | Deine KI erinnert sich endlich an dein Projekt — Fehler, Entscheidungen, Konventionen bleiben über Sessions hinweg erhalten |
| 🔍 **Semantische Suche** | Kein exakter Wortlaut nötig — suche „Datenbank-Timeout" und finde „MySQL Connection Pool Problem" |
| 💰 **50%+ Tokens sparen** | Schluss mit Copy-Paste des Projektkontexts in jeder Konversation. Semantischer Abruf bei Bedarf statt Masseninjektion |
| 🔗 **Aufgabengesteuertes Dev** | Problem-Tracking → Aufgabenzerlegung → Status-Sync → verknüpfte Archivierung. KI verwaltet den gesamten Dev-Workflow |
| 📊 **Web-Dashboard** | Visuelle Verwaltung aller Erinnerungen und Aufgaben, 3D-Vektornetzwerk zeigt Wissensverbindungen auf einen Blick |
| 🏠 **Vollständig Lokal** | Null Cloud-Abhängigkeit. ONNX lokale Inferenz, kein API Key, Daten verlassen nie deinen Rechner |
| 🔌 **Alle IDEs** | Cursor / Kiro / Claude Code / Windsurf / VSCode / OpenCode / Trae — Ein-Klick-Installation, sofort einsatzbereit |
| 📁 **Multi-Projekt-Isolation** | Eine DB für alle Projekte, automatisch isoliert ohne Interferenz, nahtloser Projektwechsel |
| 🔄 **Intelligente Deduplizierung** | Ähnlichkeit > 0.95 führt automatisch zusammen, Wissensspeicher bleibt sauber — wird nie unübersichtlich |

## 🏗️ Architektur

```
┌─────────────────────────────────────────────────┐
│                   AI IDE                         │
│  OpenCode / Claude Code / Cursor / Kiro / ...   │
└──────────────────────┬──────────────────────────┘
                       │ MCP Protocol (stdio)
┌──────────────────────▼──────────────────────────┐
│              TeamAIVectorMemory Server               │
│                                                  │
│  ┌──────────┐ ┌──────────┐ ┌──────────────────┐ │
│  │ remember │ │  recall   │ │   auto_save      │ │
│  │ forget   │ │  task     │ │   status/track   │ │
│  └────┬─────┘ └────┬─────┘ └───────┬──────────┘ │
│       │            │               │             │
│  ┌────▼────────────▼───────────────▼──────────┐  │
│  │         Embedding Engine (ONNX)            │  │
│  │      intfloat/multilingual-e5-small        │  │
│  └────────────────────┬───────────────────────┘  │
│                       │                          │
│  ┌────────────────────▼───────────────────────┐  │
│  │     SQLite + sqlite-vec (Vektorindex)      │  │
│  │     ~/.teamaivectormemory/memory.db            │  │
│  └────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────┘
```

## 🚀 Schnellstart

### Option 1: pip Installation (Empfohlen)

```bash
# Installieren
pip install teamaivectormemory

# Auf neueste Version aktualisieren
pip install --upgrade teamaivectormemory

# In dein Projektverzeichnis wechseln, Ein-Klick-IDE-Setup
cd /path/to/your/project
team-run install
```

`team-run install` führt dich interaktiv durch die IDE-Auswahl und generiert automatisch MCP-Konfiguration, Steering-Regeln und Hooks — kein manuelles Setup nötig.

> **macOS-Benutzer beachten**:
> - Bei `externally-managed-environment` Fehler: `--break-system-packages` hinzufügen
> - Bei `enable_load_extension` Fehler: Dein Python unterstützt kein SQLite-Extension-Loading (macOS-Standard-Python und python.org-Installer unterstützen es nicht). Verwende Homebrew Python:
>   ```bash
>   brew install python
>   /opt/homebrew/bin/python3 -m pip install teamaivectormemory
>   ```

### Option 2: uvx (ohne Installation)

Kein `pip install` nötig, direkt ausführen:

```bash
cd /path/to/your/project
uvx teamaivectormemory install
```

> [uv](https://docs.astral.sh/uv/getting-started/installation/) muss installiert sein. `uvx` lädt das Paket automatisch herunter und führt es aus.

### Option 3: Manuelle Konfiguration

```json
{
  "mcpServers": {
    "teamaivectormemory": {
      "command": "team-run",
      "args": ["--project-dir", "/path/to/your/project"]
    }
  }
}
```

<details>
<summary>📍 Konfigurationsdatei-Pfade nach IDE</summary>

| IDE | Konfigurationspfad |
|-----|-------------------|
| Kiro | `.kiro/settings/mcp.json` |
| Cursor | `.cursor/mcp.json` |
| Claude Code | `.mcp.json` |
| Windsurf | `.windsurf/mcp.json` |
| VSCode | `.vscode/mcp.json` |
| Trae | `.trae/mcp.json` |
| OpenCode | `opencode.json` |
| Claude Desktop | `~/Library/Application Support/Claude/claude_desktop_config.json` |

</details>

## 🛠️ 8 MCP-Werkzeuge

### `remember` — Erinnerung speichern

```
content (string, erforderlich)   Inhalt im Markdown-Format
tags    (string[], erforderlich)  Tags, z.B. ["fehler", "python"]
scope   (string)                  "project" (Standard) / "user" (projektübergreifend)
```

Ähnlichkeit > 0.95 aktualisiert automatisch bestehende Erinnerung, keine Duplikate.

### `recall` — Semantische Suche

```
query   (string)     Semantische Suchbegriffe
tags    (string[])   Exakter Tag-Filter
scope   (string)     "project" / "user" / "all"
top_k   (integer)    Anzahl der Ergebnisse, Standard 5
```

Vektorähnlichkeits-Matching — findet verwandte Erinnerungen auch bei unterschiedlicher Wortwahl.

### `forget` — Erinnerungen löschen

```
memory_id  (string)     Einzelne ID
memory_ids (string[])   Mehrere IDs
```

### `status` — Sitzungsstatus

```
state (object, optional)   Weglassen zum Lesen, übergeben zum Aktualisieren
  is_blocked, block_reason, current_task,
  next_step, progress[], recent_changes[], pending[]
```

Hält den Arbeitsfortschritt sitzungsübergreifend, stellt Kontext automatisch wieder her.

### `track` — Problem-Tracking

```
action   (string)   "create" / "update" / "archive" / "list"
title    (string)   Problemtitel
issue_id (integer)  Problem-ID
status   (string)   "pending" / "in_progress" / "completed"
content  (string)   Untersuchungsinhalt
```

### `task` — Aufgabenverwaltung

```
action     (string, erforderlich)  "batch_create" / "update" / "list" / "delete" / "archive"
feature_id (string)                Verknüpfte Funktionskennung (erforderlich für list)
tasks      (array)                 Aufgabenliste (batch_create, Unteraufgaben unterstützt)
task_id    (integer)               Aufgaben-ID (update)
status     (string)                "pending" / "in_progress" / "completed" / "skipped"
```

Über feature_id mit Spec-Dokumenten verknüpft. Update synchronisiert automatisch tasks.md Checkboxen und verknüpften Issue-Status.

### `readme` — README-Generierung

```
action   (string)    "generate" (Standard) / "diff" (Unterschiede vergleichen)
lang     (string)    Sprache: en / zh-TW / ja / de / fr / es
sections (string[])  Abschnitte angeben: header / tools / deps
```

Generiert automatisch README-Inhalte aus TOOL_DEFINITIONS / pyproject.toml, Mehrsprachigkeit unterstützt.

### `auto_save` — Automatisches Speichern von Präferenzen

```
preferences  (string[])  Vom Benutzer geäußerte technische Präferenzen (festes scope=user, projektübergreifend)
extra_tags   (string[])  Zusätzliche Tags
```

Extrahiert und speichert automatisch Benutzerpräferenzen am Ende jeder Konversation, intelligente Deduplizierung.

## 📊 Web-Dashboard

```bash
team-run web --port 9080
team-run web --port 9080 --quiet          # Anfrage-Logs unterdrücken
team-run web --port 9080 --quiet --daemon  # Im Hintergrund ausführen (macOS/Linux)
```

Besuche `http://localhost:9080` im Browser.

- Mehrere Projekte wechseln, Erinnerungen durchsuchen/bearbeiten/löschen/exportieren/importieren
- Semantische Suche (Vektorähnlichkeits-Matching)
- Projektdaten mit einem Klick löschen
- Sitzungsstatus, Problem-Tracking
- Tag-Verwaltung (Umbenennen, Zusammenführen, Stapellöschung)
- Token-Authentifizierungsschutz
- 3D-Vektornetzwerk-Visualisierung
- 🌐 Mehrsprachige Unterstützung (简体中文 / 繁體中文 / English / Español / Deutsch / Français / 日本語)

<p align="center">
  <img src="dashboard-projects.png" alt="Projektauswahl" width="100%">
  <br>
  <em>Projektauswahl</em>
</p>

<p align="center">
  <img src="dashboard-overview.png" alt="Übersicht & Vektornetzwerk-Visualisierung" width="100%">
  <br>
  <em>Übersicht & Vektornetzwerk-Visualisierung</em>
</p>

## ⚡ Gemeinsamer Embedding-Service

Mehrere MCP-Worker teilen sich ein Embedding-Modell, um redundantes Laden pro Prozess zu vermeiden (200MB × N → 200MB × 1).

```bash
# Gemeinsamen Embedding-Service starten (Standardport 8900)
team-run embed-server
team-run embed-server --port 8900              # Port angeben
team-run embed-server --port 8900 --daemon     # Im Hintergrund ausführen (macOS/Linux)
team-run embed-server --bind 0.0.0.0           # Remote-Zugriff erlauben
```

MCP-Worker verbinden sich über Umgebungsvariable mit dem gemeinsamen Service:

```json
{
  "mcpServers": {
    "teamaivectormemory": {
      "command": "team-run",
      "args": ["--project-dir", "/path/to/your/project"],
      "env": { "EMBEDDING_SERVER_URL": "http://127.0.0.1:8900" }
    }
  }
}
```

- Mit `EMBEDDING_SERVER_URL` schaltet die EmbeddingEngine automatisch in den Remote-Modus und ruft den gemeinsamen Service über HTTP auf
- Bei Nichtverfügbarkeit des gemeinsamen Service automatischer Fallback auf lokalen Modus — keine Auswirkungen
- HTTP-Schnittstellen: `GET /health` (Gesundheitscheck), `POST /encode` (Einzeltext-Encoding), `POST /encode_batch` (Batch-Encoding)

## ⚡ Kombination mit Steering-Regeln

TeamAIVectorMemory ist die Speicherschicht. Verwende Steering-Regeln, um der KI mitzuteilen, **wann und wie** sie diese Tools aufrufen soll.

`team-run install` generiert automatisch Steering-Regeln und Hooks-Konfiguration — kein manuelles Setup nötig.

| IDE | Steering-Pfad | Hooks |
|-----|--------------|-------|
| Kiro | `.kiro/steering/teamaivectormemory.md` | `.kiro/hooks/*.hook` |
| Cursor | `.cursor/rules/teamaivectormemory.md` | `.cursor/hooks.json` |
| Claude Code | `CLAUDE.md` (angehängt) | `.claude/settings.json` |
| Windsurf | `.windsurf/rules/teamaivectormemory.md` | `.windsurf/hooks.json` |
| VSCode | `.github/copilot-instructions.md` (angehängt) | — |
| Trae | `.trae/rules/teamaivectormemory.md` | — |
| OpenCode | `AGENTS.md` (angehängt) | `.opencode/plugins/*.js` |

<details>
<summary>📋 Steering-Regeln Beispiel (automatisch generiert)</summary>

```markdown
# TeamAIVectorMemory - Workflow-Regeln

## 1. Neuer Sitzungsstart (in Reihenfolge ausführen)

1. `recall` (tags: ["Projektwissen"], scope: "project", top_k: 100) Projektwissen laden
2. `recall` (tags: ["preference"], scope: "user", top_k: 20) Benutzereinstellungen laden
3. `status` (ohne state-Parameter) Sitzungsstatus lesen
4. Blockiert → berichten und warten; Nicht blockiert → Verarbeitungsfluss starten

## 2. Nachrichtenverarbeitungsfluss

- Schritt A: `status` Status lesen, bei Blockierung warten
- Schritt B: Nachrichtentyp klassifizieren (Chat/Korrektur/Präferenz/Code-Problem)
- Schritt C: `track create` Problem erfassen
- Schritt D: Untersuchen (`recall` Fehler suchen + Code prüfen + Ursache finden)
- Schritt E: Plan dem Benutzer vorstellen, Blockierung setzen für Bestätigung
- Schritt F: Code ändern (vor Änderungen `recall` Fehler prüfen)
- Schritt G: Tests zur Verifizierung ausführen
- Schritt H: Blockierung setzen für Benutzerverifizierung
- Schritt I: Benutzer bestätigt → `track archive` + Blockierung aufheben

## 3. Blockierungsregeln

Bei Planvorschlägen oder Verifizierungswartung muss `status({ is_blocked: true })` gesetzt werden.
Nur nach expliziter Benutzerbestätigung aufheben. Niemals selbst aufheben.

## 4-9. Problemverfolgung / Code-Prüfung / Spec-Aufgabenverwaltung / Erinnerungsqualität / Werkzeugübersicht / Entwicklungsstandards

(Vollständige Regeln werden automatisch von `team-run install` generiert)
```

</details>

<details>
<summary>🔗 Hooks-Konfiguration Beispiel (nur Kiro, automatisch generiert)</summary>

Automatisches Speichern bei Sitzungsende entfernt. Entwicklungsworkflow-Prüfung (`.kiro/hooks/dev-workflow-check.kiro.hook`):

```json
{
  "enabled": true,
  "name": "Entwicklungsworkflow-Prüfung",
  "version": "1",
  "when": { "type": "promptSubmit" },
  "then": {
    "type": "askAgent",
    "prompt": "Kernprinzipien: Vor dem Handeln verifizieren, kein blindes Testen, erst nach bestandenen Tests als erledigt markieren"
  }
}
```

</details>

## 🇨🇳 Nutzer in China

Das Embedding-Modell (~200MB) wird beim ersten Start automatisch heruntergeladen. Falls langsam:

```bash
export HF_ENDPOINT=https://hf-mirror.com
```

Oder env in der MCP-Konfiguration hinzufügen:

```json
{
  "env": { "HF_ENDPOINT": "https://hf-mirror.com" }
}
```

## 📦 Technologie-Stack

| Komponente | Technologie |
|------------|-----------|
| Laufzeit | Python >= 3.10 |
| Vektor-DB | SQLite + sqlite-vec |
| Embedding | ONNX Runtime + intfloat/multilingual-e5-small |
| Tokenizer | HuggingFace Tokenizers |
| Protokoll | Model Context Protocol (MCP) |
| Web | Nativer HTTPServer + Vanilla JS |

## 📋 Änderungsprotokoll

### v0.1.1

**Gemeinsamer Embedding-Service**
- ⚡ Neuer `team-run embed-server` Unterbefehl, startet einen eigenständigen Embedding-HTTP-Service (unterstützt `--port`/`--bind`/`--daemon` Parameter)
- ⚡ HTTP-Schnittstellen: `GET /health` (Gesundheitscheck), `POST /encode` (Einzeltext-Encoding), `POST /encode_batch` (Batch-Encoding)
- ⚡ EmbeddingEngine unterstützt Remote/Lokal-Dualmodus: `EMBEDDING_SERVER_URL` Umgebungsvariable schaltet automatisch auf Remote-Modus
- ⚡ Automatischer Fallback auf lokale ONNX-Inferenz bei Nichtverfügbarkeit des Remote-Service, nahtlose Degradation
- ⚡ N MCP-Worker teilen sich ein Embedding-Modell, 200MB × N → 200MB × 1, Speicherverbrauch sinkt um 90%

## License

Apache-2.0
