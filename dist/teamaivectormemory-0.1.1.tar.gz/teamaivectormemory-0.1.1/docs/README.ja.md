🌐 [简体中文](../README.md) | [繁體中文](README.zh-TW.md) | [English](README.en.md) | [Español](README.es.md) | [Deutsch](README.de.md) | [Français](README.fr.md) | 日本語

<p align="center">
  <h1 align="center">🧠 TeamAIVectorMemory</h1>
  <p align="center">
    <strong>AIコーディングアシスタントにチーム記憶を — マルチユーザー協業 · ナレッジ共有 · セッション間永続記憶MCPサーバー</strong>
  </p>
  <p align="center">
    <a href="https://pypi.org/project/teamaivectormemory/"><img src="https://img.shields.io/pypi/v/teamaivectormemory?color=blue&label=PyPI" alt="PyPI"></a>
    <a href="https://pypi.org/project/teamaivectormemory/"><img src="https://img.shields.io/pypi/pyversions/teamaivectormemory" alt="Python"></a>
    <a href="https://github.com/cmsyt/teamaivectormemory/blob/main/LICENSE"><img src="https://img.shields.io/badge/license-Apache_2.0-green" alt="License"></a>
    <a href="https://modelcontextprotocol.io"><img src="https://img.shields.io/badge/MCP-compatible-purple" alt="MCP"></a>
  </p>
</p>

---

> **こんな経験ありませんか？** 新しいセッションを開くたびに、AIはまるで別人 — 昨日教えたプロジェクト規約は今日もう忘れている、踏んだ地雷をまた踏む、途中まで進めた作業はゼロに戻る。チーム全員が同じ地雷を繰り返し踏み、知識は蓄積されず、経験は継承されない。
>
> **TeamAIVectorMemory はチームのために作られたAI記憶ハブです。** 個人の記憶だけではありません — チームの失敗経験は自動共有、アーキテクチャ知識は一人が蓄積すれば全員が恩恵を受けます。マルチユーザーデータは厳密に分離され相互干渉ゼロ。複数workerでEmbeddingモデルを共有可能：Nプロセスでメモリは1コピーのみ。新セッションは自動的にコンテキストを復元、セマンティック検索で的確に呼び出し、トークン消費を50%+削減。

## ✨ 主な機能

| 機能 | 説明 |
|------|------|
| 👥 **チームナレッジ共有** | 一人の失敗が全員の教訓に — チーム記憶は自動共有、アーキテクチャ知識や失敗経験がチーム資産として蓄積、新メンバーもベテランの全経験を即座に継承 |
| 🔐 **マルチユーザーデータ分離** | 同一サーバーで複数人が協業、個人記憶は厳密に分離され互いに不可視、チーム記憶はプロジェクト単位で共有 — プライバシーと協業を両立 |
| ⚡ **Embedding共有サービス** | N個のMCP workerが1つのEmbeddingモデルを共有、200MB × N → 200MB × 1、サーバーデプロイのメモリ消費を90%削減 |
| 🧠 **クロスセッション記憶** | AIがついにプロジェクトを覚えてくれる — 踏んだ地雷、下した決定、決めた規約、セッションが変わっても忘れない |
| 🔍 **セマンティック検索** | 原文の書き方を覚えていなくてOK —「データベースタイムアウト」で検索すれば「MySQLコネクションプール問題」が見つかる |
| 💰 **50%+トークン節約** | 毎回プロジェクト背景をコピペする必要なし。セマンティック検索でオンデマンド呼び出し、一括注入とはお別れ |
| 🔗 **タスク駆動開発** | 問題追跡 → タスク分割 → ステータス同期 → 連動アーカイブ。AIが開発フロー全体を自動管理 |
| 📊 **Webダッシュボード** | すべての記憶とタスクを視覚的に管理、3Dベクトルネットワークで知識の繋がりが一目瞭然 |
| 🏠 **完全ローカル** | クラウド依存ゼロ。ONNXローカル推論、APIキー不要、データはマシンから出ない |
| 🔌 **全IDE対応** | Cursor / Kiro / Claude Code / Windsurf / VSCode / OpenCode / Trae — ワンクリックインストール、すぐ使える |
| 📁 **マルチプロジェクト分離** | 1つのDBで全プロジェクト管理、自動分離で干渉なし、プロジェクト切り替えもシームレス |
| 🔄 **スマート重複排除** | 類似度 > 0.95 で自動マージ更新、記憶ストアは常にクリーン — 使い続けても散らからない |

## 🏗️ アーキテクチャ

```
┌─────────────────────────────────────────────────┐
│                   AI IDE                         │
│  OpenCode / Claude Code / Cursor / Kiro / ...   │
└──────────────────────┬──────────────────────────┘
                       │ MCP Protocol (stdio)
┌──────────────────────▼──────────────────────────┐
│              TeamAIVectorMemory Server               │
│                                                  │
│  ┌──────────┐ ┌──────────┐ ┌──────────────────┐ │
│  │ remember │ │  recall   │ │   auto_save      │ │
│  │ forget   │ │  task     │ │   status/track   │ │
│  └────┬─────┘ └────┬─────┘ └───────┬──────────┘ │
│       │            │               │             │
│  ┌────▼────────────▼───────────────▼──────────┐  │
│  │         Embedding Engine (ONNX)            │  │
│  │      intfloat/multilingual-e5-small        │  │
│  └────────────────────┬───────────────────────┘  │
│                       │                          │
│  ┌────────────────────▼───────────────────────┐  │
│  │     SQLite + sqlite-vec（ベクトルインデックス）│  │
│  │     ~/.teamaivectormemory/memory.db            │  │
│  └────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────┘
```

## 🚀 クイックスタート

### 方法1：pip インストール（推奨）

```bash
# インストール
pip install teamaivectormemory

# 最新版にアップグレード
pip install --upgrade teamaivectormemory

# プロジェクトディレクトリに移動し、ワンクリックで IDE を設定
cd /path/to/your/project
team-run install
```

`team-run install` は対話式で IDE を選択し、MCP 設定・Steering ルール・Hooks を自動生成します。手動設定は不要です。

> **macOS ユーザーへの注意**：
> - `externally-managed-environment` エラーが出た場合は `--break-system-packages` を追加してください
> - `enable_load_extension` エラーが出た場合、現在の Python が SQLite 拡張読み込みに対応していません（macOS 標準 Python および python.org 公式インストーラは非対応）。Homebrew Python をご利用ください：
>   ```bash
>   brew install python
>   /opt/homebrew/bin/python3 -m pip install teamaivectormemory
>   ```

### 方法2：uvx 実行（インストール不要）

`pip install` 不要、直接実行できます：

```bash
cd /path/to/your/project
uvx teamaivectormemory install
```

> 事前に [uv](https://docs.astral.sh/uv/getting-started/installation/) のインストールが必要です。`uvx` が自動的にダウンロード・実行するため、手動でのパッケージインストールは不要です。

### 方法3：手動設定

```json
{
  "mcpServers": {
    "teamaivectormemory": {
      "command": "team-run",
      "args": ["--project-dir", "/path/to/your/project"]
    }
  }
}
```

<details>
<summary>📍 各IDE設定ファイルの場所</summary>

| IDE | 設定ファイルパス |
|-----|----------------|
| Kiro | `.kiro/settings/mcp.json` |
| Cursor | `.cursor/mcp.json` |
| Claude Code | `.mcp.json` |
| Windsurf | `.windsurf/mcp.json` |
| VSCode | `.vscode/mcp.json` |
| Trae | `.trae/mcp.json` |
| OpenCode | `opencode.json` |
| Claude Desktop | `~/Library/Application Support/Claude/claude_desktop_config.json` |

</details>

## 🛠️ 8つのMCPツール

### `remember` — 記憶を保存

```
content (string, 必須)   記憶内容、Markdown形式
tags    (string[], 必須)  タグ、例 ["つまずき", "python"]
scope   (string)          "project"（デフォルト）/ "user"（プロジェクト横断）
```

類似度 > 0.95 で既存の記憶を自動更新、重複保存なし。

### `recall` — セマンティック検索

```
query   (string)     セマンティック検索キーワード
tags    (string[])   タグ精密フィルター
scope   (string)     "project" / "user" / "all"
top_k   (integer)    返却数、デフォルト 5
```

ベクトル類似度マッチング — 異なる言葉でも関連する記憶を発見。

### `forget` — 記憶を削除

```
memory_id  (string)     単一ID
memory_ids (string[])   一括ID
```

### `status` — セッション状態

```
state (object, 任意)   省略=読み取り、指定=更新
  is_blocked, block_reason, current_task,
  next_step, progress[], recent_changes[], pending[]
```

セッション間で作業進捗を維持、新セッションで自動的にコンテキストを復元。

### `track` — 問題追跡

```
action   (string)   "create" / "update" / "archive" / "list"
title    (string)   問題タイトル
issue_id (integer)  問題ID
status   (string)   "pending" / "in_progress" / "completed"
content  (string)   調査内容
```

### `task` — タスク管理

```
action     (string, 必須)  "batch_create" / "update" / "list" / "delete" / "archive"
feature_id (string)        関連機能識別子（list 時必須）
tasks      (array)         タスクリスト（batch_create、サブタスク対応）
task_id    (integer)       タスクID（update）
status     (string)        "pending" / "in_progress" / "completed" / "skipped"
```

feature_id で spec ドキュメントと連携。update で tasks.md チェックボックスと関連イシューステータスを自動同期。

### `readme` — README生成

```
action   (string)    "generate"（デフォルト）/ "diff"（差分比較）
lang     (string)    言語：en / zh-TW / ja / de / fr / es
sections (string[])  指定セクション：header / tools / deps
```

TOOL_DEFINITIONS / pyproject.toml から README コンテンツを自動生成、多言語対応。

### `auto_save` — プリファレンス自動保存

```
preferences  (string[])  ユーザーが表明した技術的プリファレンス（固定 scope=user、プロジェクト横断）
extra_tags   (string[])  追加タグ
```

各会話の終了時にユーザープリファレンスを自動抽出・保存、スマート重複排除。

## 📊 Webダッシュボード

```bash
team-run web --port 9080
team-run web --port 9080 --quiet          # リクエストログを非表示
team-run web --port 9080 --quiet --daemon  # バックグラウンド実行（macOS/Linux）
```

ブラウザで `http://localhost:9080` にアクセス。

- マルチプロジェクト切り替え、記憶の閲覧/検索/編集/削除/エクスポート/インポート
- セマンティック検索（ベクトル類似度マッチング）
- プロジェクトデータのワンクリック削除
- セッション状態、問題追跡
- タグ管理（名前変更、統合、一括削除）
- Token認証保護
- 3Dベクトル記憶ネットワーク可視化
- 🌐 多言語対応（简体中文 / 繁體中文 / English / Español / Deutsch / Français / 日本語）

<p align="center">
  <img src="dashboard-projects.png" alt="プロジェクト選択" width="100%">
  <br>
  <em>プロジェクト選択</em>
</p>

<p align="center">
  <img src="dashboard-overview.png" alt="統計概要 & ベクトルネットワーク可視化" width="100%">
  <br>
  <em>統計概要 & ベクトルネットワーク可視化</em>
</p>

## ⚡ Embedding共有サービス

複数のMCP workerが1つのEmbeddingモデルを共有し、プロセスごとの重複ロードを回避します（200MB × N → 200MB × 1）。

```bash
# Embedding共有サービスを起動（デフォルトポート 8900）
team-run embed-server
team-run embed-server --port 8900              # ポート指定
team-run embed-server --port 8900 --daemon     # バックグラウンド実行（macOS/Linux）
team-run embed-server --bind 0.0.0.0           # リモートアクセスを許可
```

MCP workerは環境変数で共有サービスに接続：

```json
{
  "mcpServers": {
    "teamaivectormemory": {
      "command": "team-run",
      "args": ["--project-dir", "/path/to/your/project"],
      "env": { "EMBEDDING_SERVER_URL": "http://127.0.0.1:8900" }
    }
  }
}
```

- `EMBEDDING_SERVER_URL` を設定すると、EmbeddingEngineは自動的にリモートモードに切り替わり、HTTP経由で共有サービスを呼び出します
- 共有サービスが利用不可の場合、自動的にローカルモードにフォールバック — 影響ゼロ
- HTTPインターフェース：`GET /health`（ヘルスチェック）、`POST /encode`（単一テキストエンコード）、`POST /encode_batch`（バッチエンコード）

## ⚡ Steeringルールとの組み合わせ

TeamAIVectorMemoryはストレージ層です。Steeringルールを使ってAIに**いつ、どのように**ツールを呼び出すかを指示します。

`team-run install` を実行すると、Steeringルールとフック設定が自動生成されます。手動設定は不要です。

| IDE | Steeringの場所 | Hooks |
|-----|---------------|-------|
| Kiro | `.kiro/steering/teamaivectormemory.md` | `.kiro/hooks/*.hook` |
| Cursor | `.cursor/rules/teamaivectormemory.md` | `.cursor/hooks.json` |
| Claude Code | `CLAUDE.md`（追記） | `.claude/settings.json` |
| Windsurf | `.windsurf/rules/teamaivectormemory.md` | `.windsurf/hooks.json` |
| VSCode | `.github/copilot-instructions.md`（追記） | — |
| Trae | `.trae/rules/teamaivectormemory.md` | — |
| OpenCode | `AGENTS.md`（追記） | `.opencode/plugins/*.js` |

<details>
<summary>📋 Steeringルール例（自動生成）</summary>

```markdown
# TeamAIVectorMemory - ワークフロールール

## 1. 新セッション起動（順番に実行必須）

1. `recall`（tags: ["プロジェクト知識"], scope: "project", top_k: 100）プロジェクト知識を読み込み
2. `recall`（tags: ["preference"], scope: "user", top_k: 20）ユーザー設定を読み込み
3. `status`（stateなし）セッション状態を読み取り
4. ブロック中 → 報告して待機；ブロックなし → 処理フローへ

## 2. メッセージ処理フロー

- ステップA：`status` で状態読み取り、ブロック中なら待機
- ステップB：メッセージ種別判定（雑談/修正/設定/コード問題）
- ステップC：`track create` で問題記録
- ステップD：調査（`recall` でつまずき検索 + コード確認 + 根本原因特定）
- ステップE：ユーザーに方針説明、ブロック設定して確認待ち
- ステップF：コード修正（修正前に `recall` でつまずき確認）
- ステップG：テスト実行で検証
- ステップH：ブロック設定してユーザー検証待ち
- ステップI：ユーザー確認 → `track archive` + ブロック解除

## 3. ブロッキングルール

方針提案時・修正完了検証待ち時は必ず `status({ is_blocked: true })`。
ユーザーの明確な確認後のみブロック解除可能。自己解除禁止。

## 4-9. 問題追跡 / コードチェック / Specタスク管理 / 記憶品質 / ツール一覧 / 開発規範

（完全なルールは `team-run install` で自動生成）
```

</details>

<details>
<summary>🔗 フック設定例（Kiro専用、自動生成）</summary>

セッション終了時の自動保存は削除済み、開発ワークフローチェック（`.kiro/hooks/dev-workflow-check.kiro.hook`）：

```json
{
  "enabled": true,
  "name": "開発ワークフローチェック",
  "version": "1",
  "when": { "type": "promptSubmit" },
  "then": {
    "type": "askAgent",
    "prompt": "核心原則：行動前に検証、盲目的なテスト禁止、テスト合格後のみ完了とマーク"
  }
}
```

</details>

## 🇨🇳 中国本土のユーザー

初回実行時にEmbeddingモデル（約200MB）が自動ダウンロードされます。遅い場合：

```bash
export HF_ENDPOINT=https://hf-mirror.com
```

またはMCP設定にenvを追加：

```json
{
  "env": { "HF_ENDPOINT": "https://hf-mirror.com" }
}
```

## 📦 技術スタック

| コンポーネント | 技術 |
|---------------|------|
| ランタイム | Python >= 3.10 |
| ベクトルDB | SQLite + sqlite-vec |
| Embedding | ONNX Runtime + intfloat/multilingual-e5-small |
| トークナイザー | HuggingFace Tokenizers |
| プロトコル | Model Context Protocol (MCP) |
| Web | ネイティブHTTPServer + Vanilla JS |

## 📋 更新履歴

### v0.1.1

**Embedding共有サービス**
- ⚡ 新しい `team-run embed-server` サブコマンド、独立したEmbedding HTTPサービスを起動（`--port`/`--bind`/`--daemon` パラメータ対応）
- ⚡ HTTPインターフェース：`GET /health`（ヘルスチェック）、`POST /encode`（単一テキストエンコード）、`POST /encode_batch`（バッチエンコード）
- ⚡ EmbeddingEngineがリモート/ローカルデュアルモードに対応：`EMBEDDING_SERVER_URL` 環境変数でリモートモードに自動切替
- ⚡ リモートサービス利用不可時にローカルONNX推論へ自動フォールバック、ゼロ影響の縮退
- ⚡ N個のMCP workerが1つのEmbeddingモデルを共有、200MB × N → 200MB × 1、メモリ使用量90%削減

## License

Apache-2.0
