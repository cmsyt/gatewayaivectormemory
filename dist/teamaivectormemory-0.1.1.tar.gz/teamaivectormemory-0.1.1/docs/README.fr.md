🌐 [简体中文](../README.md) | [繁體中文](README.zh-TW.md) | [English](README.en.md) | [Español](README.es.md) | [Deutsch](README.de.md) | Français | [日本語](README.ja.md)

<p align="center">
  <h1 align="center">🧠 TeamAIVectorMemory</h1>
  <p align="center">
    <strong>Donnez une mémoire d'équipe à votre assistant IA — Collaboration multi-utilisateurs · Partage de connaissances · Serveur MCP de mémoire persistante inter-sessions</strong>
  </p>
  <p align="center">
    <a href="https://pypi.org/project/teamaivectormemory/"><img src="https://img.shields.io/pypi/v/teamaivectormemory?color=blue&label=PyPI" alt="PyPI"></a>
    <a href="https://pypi.org/project/teamaivectormemory/"><img src="https://img.shields.io/pypi/pyversions/teamaivectormemory" alt="Python"></a>
    <a href="https://github.com/cmsyt/teamaivectormemory/blob/main/LICENSE"><img src="https://img.shields.io/badge/license-Apache_2.0-green" alt="License"></a>
    <a href="https://modelcontextprotocol.io"><img src="https://img.shields.io/badge/MCP-compatible-purple" alt="MCP"></a>
  </p>
</p>

---

> **Ça vous parle ?** À chaque nouvelle session, votre IA repart de zéro — les conventions de projet enseignées hier ? Oubliées. Les erreurs déjà commises ? Elle les refera. Le travail en cours ? Disparu. Pire encore : chaque membre de l'équipe tombe indépendamment dans les mêmes pièges, les connaissances ne s'accumulent jamais, l'expérience ne se transmet jamais.
>
> **TeamAIVectorMemory est le hub de mémoire IA conçu pour les équipes.** Pas seulement une mémoire personnelle — les expériences d'erreurs de l'équipe sont automatiquement partagées, les connaissances architecturales déposées par un seul profitent à tous. Les données multi-utilisateurs sont strictement isolées sans contamination croisée. Supporte le partage du modèle Embedding entre plusieurs workers : N processus, 1 seule copie en mémoire. Les nouvelles sessions restaurent automatiquement le contexte, la recherche sémantique retrouve exactement ce qu'il faut, et la consommation de tokens chute de 50%+.

## ✨ Fonctionnalités Principales

| Fonctionnalité | Description |
|----------------|-------------|
| 👥 **Partage de Connaissances d'Équipe** | L'erreur d'un seul devient la leçon de tous — les mémoires d'équipe sont automatiquement partagées, les connaissances architecturales et les leçons apprises deviennent des actifs d'équipe, les nouveaux membres héritent instantanément de toute l'expérience des vétérans |
| 🔐 **Isolation Multi-Utilisateurs** | Plusieurs utilisateurs sur un serveur, mémoires personnelles strictement isolées et invisibles aux autres, mémoires d'équipe partagées par projet — confidentialité et collaboration réunies |
| ⚡ **Service Embedding Partagé** | N workers MCP partagent un seul modèle Embedding, 200Mo × N → 200Mo × 1, consommation mémoire serveur réduite de 90% |
| 🧠 **Mémoire Inter-Sessions** | Votre IA se souvient enfin de votre projet — erreurs rencontrées, décisions prises, conventions établies, tout persiste entre les sessions |
| 🔍 **Recherche Sémantique** | Pas besoin de se rappeler les mots exacts — chercher « timeout base de données » trouve « erreur pool de connexions MySQL » |
| 💰 **Économie 50%+ Tokens** | Fini le copier-coller du contexte projet à chaque conversation. Récupération sémantique à la demande, adieu l'injection massive |
| 🔗 **Dev Piloté par Tâches** | Suivi des problèmes → découpage en tâches → synchronisation des statuts → archivage lié. L'IA gère tout le workflow de développement |
| 📊 **Tableau de Bord Web** | Gestion visuelle de toutes les mémoires et tâches, réseau vectoriel 3D pour voir les connexions de connaissances d'un coup d'œil |
| 🏠 **Entièrement Local** | Zéro dépendance cloud. Inférence locale ONNX, pas de clé API, les données ne quittent jamais votre machine |
| 🔌 **Tous les IDEs** | Cursor / Kiro / Claude Code / Windsurf / VSCode / OpenCode / Trae — installation en un clic, prêt à l'emploi |
| 📁 **Isolation Multi-Projets** | Une seule BD pour tous les projets, isolation automatique sans interférence, changement de projet transparent |
| 🔄 **Déduplication Intelligente** | Similarité > 0.95 fusionne automatiquement, la base de mémoires reste propre — ne devient jamais désordonnée |

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────┐
│                   AI IDE                         │
│  OpenCode / Claude Code / Cursor / Kiro / ...   │
└──────────────────────┬──────────────────────────┘
                       │ MCP Protocol (stdio)
┌──────────────────────▼──────────────────────────┐
│              TeamAIVectorMemory Server               │
│                                                  │
│  ┌──────────┐ ┌──────────┐ ┌──────────────────┐ │
│  │ remember │ │  recall   │ │   auto_save      │ │
│  │ forget   │ │  task     │ │   status/track   │ │
│  └────┬─────┘ └────┬─────┘ └───────┬──────────┘ │
│       │            │               │             │
│  ┌────▼────────────▼───────────────▼──────────┐  │
│  │         Embedding Engine (ONNX)            │  │
│  │      intfloat/multilingual-e5-small        │  │
│  └────────────────────┬───────────────────────┘  │
│                       │                          │
│  ┌────────────────────▼───────────────────────┐  │
│  │     SQLite + sqlite-vec (Index Vectoriel)  │  │
│  │     ~/.teamaivectormemory/memory.db            │  │
│  └────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────┘
```

## 🚀 Démarrage Rapide

### Option 1 : Installation pip (Recommandé)

```bash
# Installer
pip install teamaivectormemory

# Mettre à jour vers la dernière version
pip install --upgrade teamaivectormemory

# Aller dans votre répertoire de projet, configuration IDE en un clic
cd /path/to/your/project
team-run install
```

`team-run install` vous guide interactivement pour choisir votre IDE, génère automatiquement la configuration MCP, les règles Steering et les Hooks — aucune configuration manuelle nécessaire.

> **Utilisateurs macOS attention** :
> - En cas d'erreur `externally-managed-environment`, ajoutez `--break-system-packages`
> - En cas d'erreur `enable_load_extension`, votre Python ne supporte pas le chargement d'extensions SQLite (le Python intégré de macOS et les installateurs python.org ne le supportent pas). Utilisez Homebrew Python :
>   ```bash
>   brew install python
>   /opt/homebrew/bin/python3 -m pip install teamaivectormemory
>   ```

### Option 2 : uvx (sans installation)

Pas besoin de `pip install`, exécutez directement :

```bash
cd /path/to/your/project
uvx teamaivectormemory install
```

> [uv](https://docs.astral.sh/uv/getting-started/installation/) doit être installé. `uvx` télécharge et exécute automatiquement le paquet.

### Option 3 : Configuration manuelle

```json
{
  "mcpServers": {
    "teamaivectormemory": {
      "command": "team-run",
      "args": ["--project-dir", "/path/to/your/project"]
    }
  }
}
```

<details>
<summary>📍 Emplacements des fichiers de configuration par IDE</summary>

| IDE | Chemin de configuration |
|-----|------------------------|
| Kiro | `.kiro/settings/mcp.json` |
| Cursor | `.cursor/mcp.json` |
| Claude Code | `.mcp.json` |
| Windsurf | `.windsurf/mcp.json` |
| VSCode | `.vscode/mcp.json` |
| Trae | `.trae/mcp.json` |
| OpenCode | `opencode.json` |
| Claude Desktop | `~/Library/Application Support/Claude/claude_desktop_config.json` |

</details>

## 🛠️ 8 Outils MCP

### `remember` — Stocker une mémoire

```
content (string, requis)   Contenu au format Markdown
tags    (string[], requis)  Étiquettes, ex. ["erreur", "python"]
scope   (string)            "project" (par défaut) / "user" (inter-projets)
```

Similarité > 0.95 met à jour automatiquement la mémoire existante, sans doublons.

### `recall` — Recherche sémantique

```
query   (string)     Mots-clés de recherche sémantique
tags    (string[])   Filtre exact par étiquettes
scope   (string)     "project" / "user" / "all"
top_k   (integer)    Nombre de résultats, par défaut 5
```

Correspondance par similarité vectorielle — trouve des mémoires liées même avec des mots différents.

### `forget` — Supprimer des mémoires

```
memory_id  (string)     ID unique
memory_ids (string[])   IDs en lot
```

### `status` — État de session

```
state (object, optionnel)   Omettre pour lire, passer pour mettre à jour
  is_blocked, block_reason, current_task,
  next_step, progress[], recent_changes[], pending[]
```

Maintient la progression du travail entre les sessions, restaure automatiquement le contexte.

### `track` — Suivi des problèmes

```
action   (string)   "create" / "update" / "archive" / "list"
title    (string)   Titre du problème
issue_id (integer)  ID du problème
status   (string)   "pending" / "in_progress" / "completed"
content  (string)   Contenu d'investigation
```

### `task` — Gestion des tâches

```
action     (string, requis)  "batch_create" / "update" / "list" / "delete" / "archive"
feature_id (string)          Identifiant de fonctionnalité associée (requis pour list)
tasks      (array)           Liste de tâches (batch_create, sous-tâches supportées)
task_id    (integer)         ID de tâche (update)
status     (string)          "pending" / "in_progress" / "completed" / "skipped"
```

Lié aux documents spec via feature_id. Update synchronise automatiquement les checkboxes tasks.md et le statut des problèmes associés.

### `readme` — Génération de README

```
action   (string)    "generate" (par défaut) / "diff" (comparer les différences)
lang     (string)    Langue : en / zh-TW / ja / de / fr / es
sections (string[])  Sections spécifiques : header / tools / deps
```

Génère automatiquement le contenu README depuis TOOL_DEFINITIONS / pyproject.toml, support multilingue.

### `auto_save` — Sauvegarde automatique des préférences

```
preferences  (string[])  Préférences techniques exprimées par l'utilisateur (scope=user fixe, inter-projets)
extra_tags   (string[])  Étiquettes supplémentaires
```

Extrait et stocke automatiquement les préférences utilisateur à la fin de chaque conversation, déduplication intelligente.

## 📊 Tableau de Bord Web

```bash
team-run web --port 9080
team-run web --port 9080 --quiet          # Supprimer les logs de requêtes
team-run web --port 9080 --quiet --daemon  # Exécuter en arrière-plan (macOS/Linux)
```

Visitez `http://localhost:9080` dans votre navigateur.

- Basculement entre projets, parcourir/rechercher/modifier/supprimer/exporter/importer les mémoires
- Recherche sémantique (correspondance par similarité vectorielle)
- Suppression des données de projet en un clic
- État de session, suivi des problèmes
- Gestion des étiquettes (renommer, fusionner, suppression par lots)
- Protection par authentification Token
- Visualisation 3D du réseau vectoriel de mémoires
- 🌐 Support multilingue (简体中文 / 繁體中文 / English / Español / Deutsch / Français / 日本語)

<p align="center">
  <img src="dashboard-projects.png" alt="Sélection de Projet" width="100%">
  <br>
  <em>Sélection de Projet</em>
</p>

<p align="center">
  <img src="dashboard-overview.png" alt="Aperçu & Visualisation du Réseau Vectoriel" width="100%">
  <br>
  <em>Aperçu & Visualisation du Réseau Vectoriel</em>
</p>

## ⚡ Service Embedding Partagé

Plusieurs workers MCP partagent un seul modèle Embedding, évitant le chargement redondant par processus (200Mo × N → 200Mo × 1).

```bash
# Démarrer le service Embedding partagé (port par défaut 8900)
team-run embed-server
team-run embed-server --port 8900              # Spécifier le port
team-run embed-server --port 8900 --daemon     # Exécuter en arrière-plan (macOS/Linux)
team-run embed-server --bind 0.0.0.0           # Autoriser l'accès distant
```

Les workers MCP se connectent au service partagé via variable d'environnement :

```json
{
  "mcpServers": {
    "teamaivectormemory": {
      "command": "team-run",
      "args": ["--project-dir", "/path/to/your/project"],
      "env": { "EMBEDDING_SERVER_URL": "http://127.0.0.1:8900" }
    }
  }
}
```

- Avec `EMBEDDING_SERVER_URL`, l'EmbeddingEngine bascule automatiquement en mode distant et appelle le service partagé via HTTP
- En cas d'indisponibilité du service partagé, repli automatique sur le mode local — aucun impact
- Interfaces HTTP : `GET /health` (vérification de santé), `POST /encode` (encodage de texte unique), `POST /encode_batch` (encodage par lots)

## ⚡ Combinaison avec les Règles Steering

TeamAIVectorMemory est la couche de stockage. Utilisez les règles Steering pour indiquer à l'IA **quand et comment** appeler ces outils.

L'exécution de `team-run install` génère automatiquement les règles Steering et la configuration des Hooks — aucune configuration manuelle nécessaire.

| IDE | Emplacement Steering | Hooks |
|-----|---------------------|-------|
| Kiro | `.kiro/steering/teamaivectormemory.md` | `.kiro/hooks/*.hook` |
| Cursor | `.cursor/rules/teamaivectormemory.md` | `.cursor/hooks.json` |
| Claude Code | `CLAUDE.md` (ajouté) | `.claude/settings.json` |
| Windsurf | `.windsurf/rules/teamaivectormemory.md` | `.windsurf/hooks.json` |
| VSCode | `.github/copilot-instructions.md` (ajouté) | — |
| Trae | `.trae/rules/teamaivectormemory.md` | — |
| OpenCode | `AGENTS.md` (ajouté) | `.opencode/plugins/*.js` |

<details>
<summary>📋 Exemple de Règles Steering (généré automatiquement)</summary>

```markdown
# TeamAIVectorMemory - Règles de Workflow

## 1. Démarrage de Nouvelle Session (exécuter dans l'ordre)

1. `recall` (tags: ["connaissance-projet"], scope: "project", top_k: 100) charger les connaissances du projet
2. `recall` (tags: ["preference"], scope: "user", top_k: 20) charger les préférences utilisateur
3. `status` (sans paramètre state) lire l'état de la session
4. Bloqué → signaler et attendre ; Non bloqué → entrer dans le flux de traitement

## 2. Flux de Traitement des Messages

- Étape A : `status` lire l'état, attendre si bloqué
- Étape B : Classifier le type de message (discussion/correction/préférence/problème de code)
- Étape C : `track create` enregistrer le problème
- Étape D : Investiguer (`recall` chercher les erreurs + examiner le code + trouver la cause racine)
- Étape E : Présenter le plan à l'utilisateur, bloquer en attente de confirmation
- Étape F : Modifier le code (`recall` vérifier les erreurs avant modification)
- Étape G : Exécuter les tests pour vérifier
- Étape H : Bloquer en attente de vérification utilisateur
- Étape I : Utilisateur confirme → `track archive` + débloquer

## 3. Règles de Blocage

Doit `status({ is_blocked: true })` lors de propositions de plans ou d'attente de vérification.
Débloquer uniquement après confirmation explicite de l'utilisateur. Jamais d'auto-déblocage.

## 4-9. Suivi des Problèmes / Vérification du Code / Gestion Spec/Tâches / Qualité Mémoire / Référence Outils / Standards de Développement

(Règles complètes générées automatiquement par `team-run install`)
```

</details>

<details>
<summary>🔗 Exemple de Configuration Hooks (Kiro uniquement, généré automatiquement)</summary>

Sauvegarde automatique en fin de session supprimée. Vérification du workflow de développement (`.kiro/hooks/dev-workflow-check.kiro.hook`) :

```json
{
  "enabled": true,
  "name": "Vérification du Workflow de Développement",
  "version": "1",
  "when": { "type": "promptSubmit" },
  "then": {
    "type": "askAgent",
    "prompt": "Principes : vérifier avant d'agir, pas de tests à l'aveugle, ne marquer comme terminé qu'après réussite des tests"
  }
}
```

</details>

## 🇨🇳 Utilisateurs en Chine

Le modèle d'Embedding (~200Mo) est téléchargé automatiquement au premier lancement. Si c'est lent :

```bash
export HF_ENDPOINT=https://hf-mirror.com
```

Ou ajouter env dans la configuration MCP :

```json
{
  "env": { "HF_ENDPOINT": "https://hf-mirror.com" }
}
```

## 📦 Stack Technique

| Composant | Technologie |
|-----------|-----------|
| Runtime | Python >= 3.10 |
| BD Vectorielle | SQLite + sqlite-vec |
| Embedding | ONNX Runtime + intfloat/multilingual-e5-small |
| Tokenizer | HuggingFace Tokenizers |
| Protocole | Model Context Protocol (MCP) |
| Web | HTTPServer natif + Vanilla JS |

## 📋 Journal des Modifications

### v0.1.1

**Service Embedding Partagé**
- ⚡ Nouvelle sous-commande `team-run embed-server`, lance un service HTTP Embedding indépendant (supporte les paramètres `--port`/`--bind`/`--daemon`)
- ⚡ Interfaces HTTP : `GET /health` (vérification de santé), `POST /encode` (encodage de texte unique), `POST /encode_batch` (encodage par lots)
- ⚡ EmbeddingEngine supporte le double mode distant/local : la variable d'environnement `EMBEDDING_SERVER_URL` bascule automatiquement en mode distant
- ⚡ Repli automatique sur l'inférence ONNX locale en cas d'indisponibilité du service distant, dégradation transparente
- ⚡ N workers MCP partagent un seul modèle Embedding, 200Mo × N → 200Mo × 1, consommation mémoire réduite de 90%

## License

Apache-2.0
