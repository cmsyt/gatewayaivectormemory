🌐 [简体中文](../README.md) | [繁體中文](README.zh-TW.md) | [English](README.en.md) | Español | [Deutsch](README.de.md) | [Français](README.fr.md) | [日本語](README.ja.md)

<p align="center">
  <h1 align="center">🧠 TeamAIVectorMemory</h1>
  <p align="center">
    <strong>Dale memoria de equipo a tu asistente de IA — Colaboración multiusuario · Conocimiento compartido · Servidor MCP de memoria persistente entre sesiones</strong>
  </p>
  <p align="center">
    <a href="https://pypi.org/project/teamaivectormemory/"><img src="https://img.shields.io/pypi/v/teamaivectormemory?color=blue&label=PyPI" alt="PyPI"></a>
    <a href="https://pypi.org/project/teamaivectormemory/"><img src="https://img.shields.io/pypi/pyversions/teamaivectormemory" alt="Python"></a>
    <a href="https://github.com/cmsyt/teamaivectormemory/blob/main/LICENSE"><img src="https://img.shields.io/badge/license-Apache_2.0-green" alt="License"></a>
    <a href="https://modelcontextprotocol.io"><img src="https://img.shields.io/badge/MCP-compatible-purple" alt="MCP"></a>
  </p>
</p>

---

> **¿Te suena familiar?** Cada nueva sesión, tu IA empieza desde cero — las convenciones del proyecto que le enseñaste ayer? Olvidadas. Los errores que ya cometió? Los repetirá. El trabajo a medio hacer? Desaparecido. Y lo peor: cada miembro del equipo tropieza con las mismas piedras, el conocimiento no se acumula, la experiencia no se transfiere.
>
> **TeamAIVectorMemory es el hub de memoria IA diseñado para equipos.** No solo memoria personal — las experiencias del equipo se comparten automáticamente, el conocimiento arquitectónico depositado por uno beneficia a todos. Datos multiusuario estrictamente aislados sin contaminación cruzada. Soporta modelo Embedding compartido entre múltiples workers: N procesos, 1 copia en memoria (N×200MB → 1×200MB). Las nuevas sesiones restauran el contexto automáticamente, la búsqueda semántica recupera exactamente lo necesario, y el consumo de tokens baja un 50%+.

## ✨ Características Principales

| Característica | Descripción |
|----------------|-------------|
| 👥 **Conocimiento Compartido de Equipo** | Un tropiezo beneficia a todos — memorias de equipo compartidas automáticamente, conocimiento arquitectónico y lecciones aprendidas se convierten en activos del equipo, los nuevos miembros heredan toda la experiencia veterana al instante |
| 🔐 **Aislamiento de Datos Multiusuario** | Múltiples usuarios en un servidor, memorias personales estrictamente aisladas e invisibles para otros, memorias de equipo compartidas por proyecto — privacidad y colaboración en armonía |
| ⚡ **Servicio Embedding Compartido** | N workers MCP comparten un modelo Embedding, 200MB × N → 200MB × 1, la memoria del servidor baja un 90% |
| 🧠 **Memoria Entre Sesiones** | Tu IA por fin recuerda tu proyecto — errores encontrados, decisiones tomadas, convenciones establecidas, todo persiste entre sesiones |
| 🔍 **Búsqueda Semántica** | No necesitas recordar las palabras exactas — busca "timeout de base de datos" y encuentra "error en pool de conexiones MySQL" |
| 💰 **Ahorro 50%+ Tokens** | Deja de copiar y pegar el contexto del proyecto en cada conversación. Recuperación semántica bajo demanda, adiós a la inyección masiva |
| 🔗 **Dev Dirigido por Tareas** | Seguimiento de problemas → desglose de tareas → sincronización de estados → archivado vinculado. La IA gestiona todo el flujo de desarrollo |
| 📊 **Panel Web** | Gestión visual de todas las memorias y tareas, red vectorial 3D para ver conexiones de conocimiento de un vistazo |
| 🏠 **Completamente Local** | Cero dependencia de la nube. Inferencia local ONNX, sin API Key, los datos nunca salen de tu máquina |
| 🔌 **Todos los IDEs** | Cursor / Kiro / Claude Code / Windsurf / VSCode / OpenCode / Trae — instalación con un clic, listo para usar |
| 📁 **Aislamiento Multi-Proyecto** | Una sola BD para todos los proyectos, aislamiento automático sin interferencia, cambio de proyecto transparente |
| 🔄 **Deduplicación Inteligente** | Similitud > 0.95 fusiona automáticamente, la base de memorias siempre limpia — nunca se desordena con el uso |

## 🏗️ Arquitectura

```
┌─────────────────────────────────────────────────┐
│                   AI IDE                         │
│  OpenCode / Claude Code / Cursor / Kiro / ...   │
└──────────────────────┬──────────────────────────┘
                       │ MCP Protocol (stdio)
┌──────────────────────▼──────────────────────────┐
│              TeamAIVectorMemory Server               │
│                                                  │
│  ┌──────────┐ ┌──────────┐ ┌──────────────────┐ │
│  │ remember │ │  recall   │ │   auto_save      │ │
│  │ forget   │ │  task     │ │   status/track   │ │
│  └────┬─────┘ └────┬─────┘ └───────┬──────────┘ │
│       │            │               │             │
│  ┌────▼────────────▼───────────────▼──────────┐  │
│  │         Embedding Engine (ONNX)            │  │
│  │      intfloat/multilingual-e5-small        │  │
│  └────────────────────┬───────────────────────┘  │
│                       │                          │
│  ┌────────────────────▼───────────────────────┐  │
│  │     SQLite + sqlite-vec (Índice Vectorial) │  │
│  │     ~/.teamaivectormemory/memory.db            │  │
│  └────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────┘
```

## 🚀 Inicio Rápido

### Opción 1: Instalación con pip (Recomendado)

```bash
# Instalar
pip install teamaivectormemory

# Actualizar a la última versión
pip install --upgrade teamaivectormemory

# Ir al directorio de tu proyecto, configuración IDE con un clic
cd /path/to/your/project
team-run install
```

`team-run install` te guía interactivamente para seleccionar tu IDE, generando automáticamente la configuración MCP, reglas Steering y Hooks — sin configuración manual.

> **Usuarios de macOS**:
> - Si aparece el error `externally-managed-environment`, agrega `--break-system-packages`
> - Si aparece el error `enable_load_extension`, tu Python no soporta la carga de extensiones SQLite (el Python integrado de macOS y los instaladores de python.org no lo soportan). Usa Homebrew Python:
>   ```bash
>   brew install python
>   /opt/homebrew/bin/python3 -m pip install teamaivectormemory
>   ```

### Opción 2: uvx (sin instalación)

No necesitas `pip install`, ejecuta directamente:

```bash
cd /path/to/your/project
uvx teamaivectormemory install
```

> Requiere tener [uv](https://docs.astral.sh/uv/getting-started/installation/) instalado. `uvx` descarga y ejecuta el paquete automáticamente.

### Opción 3: Configuración manual

```json
{
  "mcpServers": {
    "teamaivectormemory": {
      "command": "team-run",
      "args": ["--project-dir", "/path/to/your/project"]
    }
  }
}
```

<details>
<summary>📍 Ubicación de archivos de configuración por IDE</summary>

| IDE | Ruta de configuración |
|-----|----------------------|
| Kiro | `.kiro/settings/mcp.json` |
| Cursor | `.cursor/mcp.json` |
| Claude Code | `.mcp.json` |
| Windsurf | `.windsurf/mcp.json` |
| VSCode | `.vscode/mcp.json` |
| Trae | `.trae/mcp.json` |
| OpenCode | `opencode.json` |
| Claude Desktop | `~/Library/Application Support/Claude/claude_desktop_config.json` |

</details>

## 🛠️ 8 Herramientas MCP

### `remember` — Almacenar memoria

```
content (string, requerido)   Contenido en formato Markdown
tags    (string[], requerido)  Etiquetas, ej. ["error", "python"]
scope   (string)               "project" (por defecto) / "user" (entre proyectos)
```

Similitud > 0.95 actualiza automáticamente la memoria existente, sin duplicados.

### `recall` — Búsqueda semántica

```
query   (string)     Palabras clave de búsqueda semántica
tags    (string[])   Filtro exacto por etiquetas
scope   (string)     "project" / "user" / "all"
top_k   (integer)    Número de resultados, por defecto 5
```

Coincidencia por similitud vectorial — encuentra memorias relacionadas incluso con palabras diferentes.

### `forget` — Eliminar memorias

```
memory_id  (string)     ID individual
memory_ids (string[])   IDs en lote
```

### `status` — Estado de sesión

```
state (object, opcional)   Omitir para leer, pasar para actualizar
  is_blocked, block_reason, current_task,
  next_step, progress[], recent_changes[], pending[]
```

Mantiene el progreso de trabajo entre sesiones, restaura contexto automáticamente.

### `track` — Seguimiento de problemas

```
action   (string)   "create" / "update" / "archive" / "list"
title    (string)   Título del problema
issue_id (integer)  ID del problema
status   (string)   "pending" / "in_progress" / "completed"
content  (string)   Contenido de investigación
```

### `task` — Gestión de tareas

```
action     (string, requerido)  "batch_create" / "update" / "list" / "delete" / "archive"
feature_id (string)             Identificador de funcionalidad asociada (requerido para list)
tasks      (array)              Lista de tareas (batch_create, soporta subtareas)
task_id    (integer)            ID de tarea (update)
status     (string)             "pending" / "in_progress" / "completed" / "skipped"
```

Vinculado a documentos spec mediante feature_id. Update sincroniza automáticamente checkboxes de tasks.md y estado de problemas asociados.

### `readme` — Generación de README

```
action   (string)    "generate" (por defecto) / "diff" (comparar diferencias)
lang     (string)    Idioma: en / zh-TW / ja / de / fr / es
sections (string[])  Secciones específicas: header / tools / deps
```

Genera automáticamente contenido README desde TOOL_DEFINITIONS / pyproject.toml, soporte multiidioma.

### `auto_save` — Guardado automático de preferencias

```
preferences  (string[])  Preferencias técnicas expresadas por el usuario (scope=user fijo, entre proyectos)
extra_tags   (string[])  Etiquetas adicionales
```

Extrae y almacena automáticamente las preferencias del usuario al final de cada conversación, deduplicación inteligente.

## 📊 Panel Web

```bash
team-run web --port 9080
team-run web --port 9080 --quiet          # Suprimir logs de solicitudes
team-run web --port 9080 --quiet --daemon  # Ejecutar en segundo plano (macOS/Linux)
```

Visita `http://localhost:9080` en tu navegador.

- Cambio entre múltiples proyectos, explorar/buscar/editar/eliminar/exportar/importar memorias
- Búsqueda semántica (coincidencia por similitud vectorial)
- Eliminación de datos de proyecto con un clic
- Estado de sesión, seguimiento de problemas
- Gestión de etiquetas (renombrar, fusionar, eliminación por lotes)
- Protección por autenticación Token
- Visualización 3D de red vectorial de memorias
- 🌐 Soporte multilingüe (简体中文 / 繁體中文 / English / Español / Deutsch / Français / 日本語)

<p align="center">
  <img src="dashboard-projects.png" alt="Selección de Proyecto" width="100%">
  <br>
  <em>Selección de Proyecto</em>
</p>

<p align="center">
  <img src="dashboard-overview.png" alt="Resumen y Visualización de Red Vectorial" width="100%">
  <br>
  <em>Resumen y Visualización de Red Vectorial</em>
</p>

## ⚡ Servicio Embedding Compartido

Múltiples workers MCP comparten un solo modelo Embedding, evitando la carga redundante por proceso (200MB × N → 200MB × 1).

```bash
# Iniciar el servicio Embedding compartido (puerto por defecto 8900)
team-run embed-server
team-run embed-server --port 8900              # Especificar puerto
team-run embed-server --port 8900 --daemon     # Ejecutar en segundo plano (macOS/Linux)
team-run embed-server --bind 0.0.0.0           # Permitir acceso remoto
```

Los workers MCP se conectan al servicio compartido mediante variable de entorno:

```json
{
  "mcpServers": {
    "teamaivectormemory": {
      "command": "team-run",
      "args": ["--project-dir", "/path/to/your/project"],
      "env": { "EMBEDDING_SERVER_URL": "http://127.0.0.1:8900" }
    }
  }
}
```

- Con `EMBEDDING_SERVER_URL`, el EmbeddingEngine cambia automáticamente al modo remoto y llama al servicio compartido vía HTTP
- Si el servicio compartido no está disponible, retroceso automático al modo local — sin impacto
- Interfaces HTTP: `GET /health` (verificación de salud), `POST /encode` (codificación de texto único), `POST /encode_batch` (codificación por lotes)

## ⚡ Combinación con Reglas Steering

TeamAIVectorMemory es la capa de almacenamiento. Usa reglas Steering para indicar a la IA **cuándo y cómo** llamar estas herramientas.

Ejecutar `team-run install` genera automáticamente las reglas Steering y la configuración de Hooks, sin necesidad de escribirlas manualmente.

| IDE | Ubicación de Steering | Hooks |
|-----|----------------------|-------|
| Kiro | `.kiro/steering/teamaivectormemory.md` | `.kiro/hooks/*.hook` |
| Cursor | `.cursor/rules/teamaivectormemory.md` | `.cursor/hooks.json` |
| Claude Code | `CLAUDE.md` (añadido) | `.claude/settings.json` |
| Windsurf | `.windsurf/rules/teamaivectormemory.md` | `.windsurf/hooks.json` |
| VSCode | `.github/copilot-instructions.md` (añadido) | — |
| Trae | `.trae/rules/teamaivectormemory.md` | — |
| OpenCode | `AGENTS.md` (añadido) | `.opencode/plugins/*.js` |

<details>
<summary>📋 Ejemplo de Reglas Steering (generado automáticamente)</summary>

```markdown
# TeamAIVectorMemory - Reglas de Flujo de Trabajo

## 1. Inicio de Nueva Sesión (ejecutar en orden)

1. `recall` (tags: ["conocimiento-proyecto"], scope: "project", top_k: 100) cargar conocimiento del proyecto
2. `recall` (tags: ["preference"], scope: "user", top_k: 20) cargar preferencias del usuario
3. `status` (sin parámetro state) leer estado de sesión
4. Bloqueado → reportar y esperar; No bloqueado → entrar al flujo de procesamiento

## 2. Flujo de Procesamiento de Mensajes

- Paso A: `status` leer estado, esperar si bloqueado
- Paso B: Clasificar tipo de mensaje (chat/corrección/preferencia/problema de código)
- Paso C: `track create` registrar problema
- Paso D: Investigar (`recall` buscar errores + revisar código + encontrar causa raíz)
- Paso E: Presentar plan al usuario, establecer bloqueo esperando confirmación
- Paso F: Modificar código (`recall` buscar errores antes de cambios)
- Paso G: Ejecutar pruebas para verificar
- Paso H: Establecer bloqueo esperando verificación del usuario
- Paso I: Usuario confirma → `track archive` + desbloquear

## 3. Reglas de Bloqueo

Debe `status({ is_blocked: true })` al proponer planes o esperar verificación.
Solo desbloquear tras confirmación explícita del usuario. Nunca auto-desbloquear.

## 4-9. Seguimiento de Problemas / Verificación de Código / Gestión Spec/Tareas / Calidad de Memoria / Referencia de Herramientas / Estándares de Desarrollo

(Reglas completas generadas automáticamente por `team-run install`)
```

</details>

<details>
<summary>🔗 Ejemplo de Configuración de Hooks (solo Kiro, generado automáticamente)</summary>

Guardado automático al finalizar sesión eliminado. Verificación del flujo de desarrollo (`.kiro/hooks/dev-workflow-check.kiro.hook`):

```json
{
  "enabled": true,
  "name": "Verificación del Flujo de Desarrollo",
  "version": "1",
  "when": { "type": "promptSubmit" },
  "then": {
    "type": "askAgent",
    "prompt": "Principios: verificar antes de actuar, no probar a ciegas, solo marcar como completado después de pasar las pruebas"
  }
}
```

</details>

## 🇨🇳 Usuarios en China

El modelo de Embedding (~200MB) se descarga automáticamente en la primera ejecución. Si es lento:

```bash
export HF_ENDPOINT=https://hf-mirror.com
```

O agregar env en la configuración MCP:

```json
{
  "env": { "HF_ENDPOINT": "https://hf-mirror.com" }
}
```

## 📦 Stack Tecnológico

| Componente | Tecnología |
|------------|-----------|
| Runtime | Python >= 3.10 |
| BD Vectorial | SQLite + sqlite-vec |
| Embedding | ONNX Runtime + intfloat/multilingual-e5-small |
| Tokenizador | HuggingFace Tokenizers |
| Protocolo | Model Context Protocol (MCP) |
| Web | HTTPServer nativo + Vanilla JS |

## 📋 Registro de Cambios

### v0.1.1

**Servicio Embedding Compartido**
- ⚡ Nuevo subcomando `team-run embed-server`, inicia un servicio HTTP Embedding independiente (soporta parámetros `--port`/`--bind`/`--daemon`)
- ⚡ Interfaces HTTP: `GET /health` (verificación de salud), `POST /encode` (codificación de texto único), `POST /encode_batch` (codificación por lotes)
- ⚡ EmbeddingEngine soporta modo dual remoto/local: la variable de entorno `EMBEDDING_SERVER_URL` cambia automáticamente al modo remoto
- ⚡ Retroceso automático a inferencia ONNX local cuando el servicio remoto no está disponible, degradación transparente
- ⚡ N workers MCP comparten un solo modelo Embedding, 200MB × N → 200MB × 1, consumo de memoria reducido en 90%

## License

Apache-2.0
